package org.serratec.backend.exception;

public class ContaException extends RuntimeException {
    public ContaException(String message) {
        super(message);
    }
}
