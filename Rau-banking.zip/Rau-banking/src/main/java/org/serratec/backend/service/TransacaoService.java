package org.serratec.backend.service;

import org.serratec.backend.entity.Conta;
import org.serratec.backend.entity.Transacao;
import org.serratec.backend.exception.ContaException;
import org.serratec.backend.repository.ContaRepository;
import org.serratec.backend.repository.TransacaoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class TransacaoService {

    private ContaService cs;

    @Autowired
    private TransacaoRepository repository;

    public Transacao inserir (Transacao transacao) {

        if (cs.buscarPorId(transacao.getContaOrigem().getId())) {



            throw new ContaException("Cpf já cadastrado");
        }
        return repository.save(conta);
    }

    public List<Conta> listar() {
        return repository.findAll();
    }

}
